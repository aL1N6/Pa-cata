document.addEventListener("DOMContentLoaded", () => {
    const calendar = document.getElementById("calendar");
    const giftModal = document.getElementById("giftModal");
    const giftMessage = document.getElementById("giftMessage");
    const closeModal = document.querySelector(".close");

    // Frases personalizadas para cada personaje de Sanrio, ahora con el orden correcto
    const phrases = [
        "Como Keroppi, mi amor por ti es tan grande como el pantano donde vivo, lleno de alegría y energía. Juntos, cada día es una nueva aventura llena de risas, amor y momentos inolvidables.", // Keroppi
        "Como los Little Twin Stars, siempre estaré a tu lado, brillando juntos como las estrellas en el cielo. No importa cuán lejos estemos, mi amor por ti será tan eterno y brillante como el universo mismo.", // Little Twin Stars
        "Como Kuromi, no sigo las reglas, pero por ti haría cualquier cosa. Mi amor por ti es tan audaz y único como mi espíritu rebelde, y no tengo miedo de mostrarte lo que siento, siempre con mi toque especial de locura y pasión.", // Kuromi
        "Como Chococat, me encanta compartir cada momento contigo y descubrir juntos nuevas aventuras.", // Chococat
        "Eres mi fuerza en los momentos difíciles y mi paz cuando todo se calma, como Aggretsuko, que encuentra su equilibrio entre la vida y sus emociones.", // Aggretsuko
        "Eres mi compañero en la aventura, siempre con actitud y sin miedo de ser diferente, como Badtz-Maru, que me inspira a ser auténtico y valiente.", // Badtz-Maru
        "Nuestro amor es tan suave y tierno como Gudetama descansando tranquilo en su cascarón.", // Gudetama
        "Mi amor por ti es tan inmenso como el lazo que une a Hello Kitty con todos los que la quieren.", // Hello Kitty
        "Eres la calma y la dulzura de mi vida, como My Melody, siempre llena de ternura.", // My Melody
        "Al igual que Cinnamoroll, contigo todo es mágico y cada día es una nueva aventura de amor.", // Cinnamoroll
        "Tu alegría y energía son mi motor diario, como Pochacco, que siempre enfrenta la vida con una sonrisa y un corazón lleno de amor.", // Pochacco
        "Tu amor es mi refugio, como Pompompurin, siempre a tu lado para brindarte lo mejor de mí.", // Pompompurrin
        "Contigo, cada momento se vuelve más dulce y especial, como Macaron y Pompompurin, juntos haciendo que el amor sea más delicioso y lleno de ternura.", // Macaron 
        "Eres mi razón para sonreír, como Pochamii, que con su ternura y su alegría llena de colores, hace que cada día sea más brillante y especial.", // Pochamii
        "Juntos, como los Cheery Chums, hacemos que cada día sea una fiesta de amistad, amor y alegría, compartiendo momentos llenos de risas y ternura.", // CHEERY CHUMS
        "Tu ternura es mi refugio, como Coro Coro Kuririn, que con su suavidad y dulzura convierte cada momento en algo mágico y lleno de paz.", // coro coro kuririn
        "Eres mi calma en medio del caos, como Tenorikuma, que con su tranquilidad y dulzura siempre sabe cómo hacer que el día sea más sereno y lleno de amor.", // tenorikuma
      "Como Mimmy White, me haces ver la belleza en los pequeños detalles, con tu ternura y gracia que hacen que todo a tu alrededor sea más brillante y lleno de amor.", // mimmy white
      "Eres mi dulzura y mi alegría, como Bonbonribbon, que con su delicadeza y su espíritu alegre convierte cada día en una hermosa celebración de amor y amistad", // bonbonribbon
      "Como Wish Me Mell, haces que mis sueños sean más coloridos y dulces, llenando mi corazón de esperanza y amor con cada deseo que compartimos.", // Wish me mell
      "Eres mi alegría en los días nublados, como Pekkle, que siempre con su simpatía y espíritu juguetón sabe cómo alegrar cada momento.", // pekkle
      "Como Hangyodon, aunque a veces me equivoque y me meta en líos, siempre encontraré la manera de hacerte sonreír, porque tenerte a mi lado convierte cada momento en una aventura llena de amor y risas.", // hangyodon
      "Como Dear Daniel, siempre estaré a tu lado, escuchándote y apoyándote, porque tu felicidad es la que llena mi corazón de amor y alegría.", // dear daniel
      "Como Tuxedo Sam, me esfuerzo por ser tu compañero fiel, siempre con elegancia y ternura, porque no hay nada más especial que verte sonreír y saber que juntos, cada momento se convierte en una historia de amor y felicidad.", // tuxedo sam
       
    ];

    // Imágenes de Sanrio para cada día en el calendario, respetando el orden
    const sanrioImages = [
        "https://i.pinimg.com/736x/aa/8c/be/aa8cbe2db9fd38cf78fb22c67bbfc9b4.jpg", 
        "https://i.pinimg.com/736x/4b/19/b4/4b19b4827b816bdbfaa2eee269a60d45.jpg", 
        "https://i.pinimg.com/736x/f5/b7/a8/f5b7a852d0ed61be94b16b7aeb652f22.jpg", 
        "https://i.pinimg.com/736x/82/2a/5e/822a5ecebbb26387e5f5e55bb3d7bdc2.jpg", 
        "https://i.pinimg.com/736x/4e/03/4e/4e034eeffdd5a866264f1d4a6ba792de.jpg", 
        "https://i.pinimg.com/736x/c6/0a/4c/c60a4c98068e3768b4b0db587c2059e4.jpg", 
        "https://i.pinimg.com/736x/dd/0f/51/dd0f510a330c1df04dc2c2c29b9999d7.jpg", 
        "https://i.pinimg.com/736x/93/c3/34/93c3344e34a924094db3311d3869353d.jpg", 
        "https://i.pinimg.com/736x/2b/59/53/2b5953f915d67632cd21830835aa7e23.jpg", 
        "https://i.pinimg.com/736x/75/72/96/757296d4c8e5f8d08d7a1419bf9b496d.jpg", 
        "https://i.pinimg.com/736x/07/fc/83/07fc8347b2a3d6267750c703b92e6c2e.jpg", 
        "https://i.pinimg.com/736x/32/00/02/3200021c985704f00e64a6021ada6ffa.jpg", 
        "https://i.pinimg.com/736x/bd/d5/45/bdd545544b6d242990d30e0322dd6c69.jpg", 
        "https://i.pinimg.com/736x/59/a6/ed/59a6ede40a9c27fcb6986a9f1c035efe.jpg", 
        "https://i.pinimg.com/736x/91/e8/66/91e866ee59d61b75677e02d363f56f30.jpg", 
        "https://i.pinimg.com/736x/de/44/fe/de44fe6201accf92233687726bf85f97.jpg", 
        "https://i.pinimg.com/736x/d8/ec/55/d8ec556d8bb2c5f5ad9c2ec4e37fe9e1.jpg",
      "https://i.pinimg.com/736x/b6/ac/88/b6ac88891477d36b5f48ff7c2c254427.jpg",
      "https://i.pinimg.com/736x/cb/26/ba/cb26ba934774ba5081673ea414743826.jpg",
      "https://i.pinimg.com/736x/0b/4e/be/0b4ebe4f639f875b887bf17ab887299e.jpg",
      "https://i.pinimg.com/736x/9b/f1/6c/9bf16ce950acbc6cc2a3ad29603c921a.jpg",
      "https://i.pinimg.com/736x/61/59/e3/6159e32dfad11c092cdeade6533e49f6.jpg",
      "https://i.pinimg.com/736x/eb/12/01/eb1201dfeb36f62ad6aa57e239aabbd8.jpg",
      "https://i.pinimg.com/736x/a4/4c/49/a44c49834d4d69f2a3abe90d51bff36d.jpg",
    ];

    // Crear las cajas del calendario
    for (let i = 0; i < 24; i++) {
        const box = document.createElement("div");
        box.classList.add("box");
        box.style.backgroundImage = `url(${sanrioImages[i]})`;

        // Mostrar el mensaje correspondiente al hacer clic en la caja
        box.addEventListener("click", () => {
            giftMessage.textContent = phrases[i];
            giftModal.style.display = "flex";
        });

        calendar.appendChild(box);
    }

    closeModal.addEventListener("click", () => {
        giftModal.style.display = "none";
    });

    window.addEventListener("click", (event) => {
        if (event.target === giftModal) {
            giftModal.style.display = "none";
        }
    });
});
